#!/usr/bin/env bash
set -euo pipefail

# V2 wrapper:
# - reinforces neutral-zone breathing before soft anomaly can cut
# - wider trailing giveback (less nervous)
# - keeps strict clone core and Futures pipes

cd /Users/christophe/ace777-test-day1

export TRAIL_GIVEBACK_BPS="${TRAIL_GIVEBACK_BPS:-3}"
export SOFT_TRAIL_GIVEBACK_BPS="${SOFT_TRAIL_GIVEBACK_BPS:-3}"
export MIN_HOLD_FOR_ANOMALY="${MIN_HOLD_FOR_ANOMALY:-3}"
export SOFT_NEUTRAL_HOLD_SEC="${SOFT_NEUTRAL_HOLD_SEC:-60}"
export NEUTRAL_PNL_MIN_BPS="${NEUTRAL_PNL_MIN_BPS:--1}"
export NEUTRAL_PNL_MAX_BPS="${NEUTRAL_PNL_MAX_BPS:-5}"
export LEVERAGE_ANOMALY_MULT="${LEVERAGE_ANOMALY_MULT:-0.5}"
export BOT_LABEL="${BOT_LABEL:-$(basename "${LOG_FILE:-ACE777}")}"
export RUN_DURATION_SEC="${RUN_DURATION_SEC:-0}"
export RUN_START_EPOCH="${RUN_START_EPOCH:-$(date +%s)}"

# Prefix every live output line with UTC timestamp + bot label + elapsed.
bash ./ACE777_STRICT_CLONE_FUTURES.sh 2>&1 | while IFS= read -r line; do
  now_epoch="$(date +%s)"
  elapsed=$((now_epoch - RUN_START_EPOCH))
  if [ "$RUN_DURATION_SEC" -gt 0 ]; then
    rem=$((RUN_DURATION_SEC - elapsed))
    if [ "$rem" -lt 0 ]; then rem=0; fi
    timer="t+${elapsed}s r-${rem}s"
  else
    timer="t+${elapsed}s"
  fi
  printf '%s [%s] %s | %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$BOT_LABEL" "$line" "$timer"
done
