#!/usr/bin/env bash
set -euo pipefail

# ACE777 STRICT CLONE FUTURES
# Clone decisionnel strict (radar + structure + tactic + soft-anomaly),
# transposé sur tuyaux Futures Testnet.

: "${BINANCE_API_KEY:?missing BINANCE_API_KEY}"
: "${BINANCE_API_SECRET:?missing BINANCE_API_SECRET}"

BASE_URL="${BASE_URL:-https://testnet.binancefuture.com}"
SYMBOL="${SYMBOL:-BTCUSDT}"
LEVERAGE="${LEVERAGE:-5}"
BUY_USDT="${BUY_USDT:-500}"
CYCLES="${CYCLES:-999999}"
SLEEP_SEC="${SLEEP_SEC:-1}"
POLL_SEC="${POLL_SEC:-0.5}"
MOMENTUM_SLEEP_SEC="${MOMENTUM_SLEEP_SEC:-1}"
RECV_WINDOW="${RECV_WINDOW:-60000}"
STOP_FILE="${STOP_FILE:-STOP}"
LOG_FILE="${LOG_FILE:-ACE777_STRICT_CLONE_FUTURES.csv}"
ENABLE_ORDERS="${ENABLE_ORDERS:-TRUE}"
FORCE_ENTRY_SIDE="${FORCE_ENTRY_SIDE:-AUTO}"   # AUTO | BUY | SELL
POSITION_SIDE="${POSITION_SIDE:-BOTH}"         # BOTH | LONG | SHORT

# Core strategy controls (baseline 7h style)
MIN_PROFIT_BPS="${MIN_PROFIT_BPS:-15}"
STOP_LOSS_BPS="${STOP_LOSS_BPS:-10}"
MAX_HOLD_SEC="${MAX_HOLD_SEC:-150}"
MIN_HOLD_SEC="${MIN_HOLD_SEC:-15}"
TRAIL_ARM_BPS="${TRAIL_ARM_BPS:-5}"
TRAIL_GIVEBACK_BPS="${TRAIL_GIVEBACK_BPS:-3}"
USE_TRAILING="${USE_TRAILING:-1}"

# Radar / structure / tactic
RADAR_GATE="${RADAR_GATE:-TRUE}"
RADAR_MIN_CONF="${RADAR_MIN_CONF:-0.30}"
RADAR_MIN_MOM_BPS="${RADAR_MIN_MOM_BPS:-0.01}"
RADAR_DIR_BPS="${RADAR_DIR_BPS:-0.20}"
RADAR_MAX_SPREAD_BPS="${RADAR_MAX_SPREAD_BPS:-8}"
MOMENTUM_THRESHOLD="${MOMENTUM_THRESHOLD:-${MOMENTUM_THRESHOLD_BPS:-0.01}}"
TREND_FILTER="${TREND_FILTER:-TRUE}"
STRUCTURE_LOOKBACK_MIN="${STRUCTURE_LOOKBACK_MIN:-3}"
ENTRY_SIGNAL="${ENTRY_SIGNAL:-CROSSOVER}"

# Soft anomaly
ANOMALY_SOFT_MODE="${ANOMALY_SOFT_MODE:-TRUE}"
ANOMALY_TICK_BPS="${ANOMALY_TICK_BPS:-40}"
ANOMALY_PNL_USDT="${ANOMALY_PNL_USDT:-0.05}"
SOFT_COOLDOWN_CYCLES="${SOFT_COOLDOWN_CYCLES:-3}"
SOFT_MASS_FACTOR="${SOFT_MASS_FACTOR:-0.5}"
SOFT_STOP_LOSS_BPS="${SOFT_STOP_LOSS_BPS:-7}"
SOFT_TRAIL_GIVEBACK_BPS="${SOFT_TRAIL_GIVEBACK_BPS:-3}"
MIN_HOLD_FOR_ANOMALY="${MIN_HOLD_FOR_ANOMALY:-3}"
LEVERAGE_ANOMALY_MULT="${LEVERAGE_ANOMALY_MULT:-0.5}"
SOFT_NEUTRAL_HOLD_SEC="${SOFT_NEUTRAL_HOLD_SEC:-60}"
NEUTRAL_PNL_MIN_BPS="${NEUTRAL_PNL_MIN_BPS:--1}"
NEUTRAL_PNL_MAX_BPS="${NEUTRAL_PNL_MAX_BPS:-5}"
DYNAMIC_SIZING_ENABLED="${DYNAMIC_SIZING_ENABLED:-TRUE}"
DYNAMIC_SIZE_CONF_LOW="${DYNAMIC_SIZE_CONF_LOW:-0.15}"
DYNAMIC_SIZE_CONF_HIGH="${DYNAMIC_SIZE_CONF_HIGH:-0.25}"
DYNAMIC_SIZE_WEAK_FACTOR="${DYNAMIC_SIZE_WEAK_FACTOR:-0.5}"

# Fatigue
CALORIE_EFFICIENCY_EXIT="${CALORIE_EFFICIENCY_EXIT:-TRUE}"
STALL_THRESHOLD_BPS_PER_SEC="${STALL_THRESHOLD_BPS_PER_SEC:-0.1}"
FATIGUE_CONFIRMATIONS="${FATIGUE_CONFIRMATIONS:-20}"

# Duo Scout/Hunter (optional; disabled by default)
DUO_MODE="${DUO_MODE:-FALSE}"                    # TRUE | FALSE
DUO_ROLE="${DUO_ROLE:-NONE}"                     # NONE | SCOUT | HUNTER
DUO_STATE_FILE="${DUO_STATE_FILE:-runs/duo_state.json}"
DUO_EVENT_TTL_SEC="${DUO_EVENT_TTL_SEC:-20}"
DUO_SCOUT_SUFFER_BPS="${DUO_SCOUT_SUFFER_BPS:--5}"
DUO_SCOUT_SUFFER_USDT="${DUO_SCOUT_SUFFER_USDT:--0.50}"
DUO_HUNTER_REVENGE_MULT="${DUO_HUNTER_REVENGE_MULT:-1.5}"
DUO_HUNTER_REQUIRE_STOP_LOSS="${DUO_HUNTER_REQUIRE_STOP_LOSS:-TRUE}"
DUO_FORCE_OPPOSITE="${DUO_FORCE_OPPOSITE:-TRUE}"
DUO_HUNTER_PERSIST_LINK="${DUO_HUNTER_PERSIST_LINK:-TRUE}"
DUO_HUNTER_HARD_STOP_MULT="${DUO_HUNTER_HARD_STOP_MULT:-2.0}"
DUO_HUNTER_MAX_HOLD_SEC="${DUO_HUNTER_MAX_HOLD_SEC:-240}"
DUO_HUNTER_STOP_LOSS_BPS="${DUO_HUNTER_STOP_LOSS_BPS:-0}"
DUO_GLOBAL_STOP_SESSION_USDT="${DUO_GLOBAL_STOP_SESSION_USDT:-0}"
DUO_SESSION_FILE="${DUO_SESSION_FILE:-runs/duo_session.json}"
DUO_MOMENTUM_HANDOVER="${DUO_MOMENTUM_HANDOVER:-FALSE}"
DUO_HUNTER_AGGR_TRAIL_ARM_BPS="${DUO_HUNTER_AGGR_TRAIL_ARM_BPS:-2}"
DUO_HUNTER_AGGR_TRAIL_GIVEBACK_BPS="${DUO_HUNTER_AGGR_TRAIL_GIVEBACK_BPS:-1}"

if [[ "$BASE_URL" != *"testnet.binancefuture.com"* ]]; then
  echo "Abort: BASE_URL must be Futures Testnet."
  exit 1
fi

if [ ! -f "$LOG_FILE" ]; then
  echo "ts,cycle,side,status,entryPrice,exitPrice,qty,bps,pnl,exitReason,holdSec,msg" > "$LOG_FILE"
fi

now_ms() { ruby -e 'puts (Time.now.to_f * 1000).to_i'; }
now_sec() { ruby -e 'puts Time.now.to_i'; }
duo_enabled() { [ "$DUO_MODE" = "TRUE" ]; }
duo_is_scout() { duo_enabled && [ "$DUO_ROLE" = "SCOUT" ]; }
duo_is_hunter() { duo_enabled && [ "$DUO_ROLE" = "HUNTER" ]; }

if duo_enabled; then
  mkdir -p "$(dirname "$DUO_STATE_FILE")"
  mkdir -p "$(dirname "$DUO_SESSION_FILE")"
fi

sign() {
  local q="$1"
  printf '%s' "$q" | openssl dgst -sha256 -hmac "$BINANCE_API_SECRET" -binary | xxd -p -c 256
}

json_get() {
  local json="$1" key="$2"
  ruby -rjson -e 'j=JSON.parse(STDIN.read) rescue {}; v=j[ARGV[0]]; print(v.nil? ? "" : v)' "$key" <<< "$json"
}

as_num() { ruby -e 'n=(Float(ARGV[0]) rescue 0.0); printf("%.8f", n)' -- "$1"; }
abs_num() { ruby -e 'x=(Float(ARGV[0]) rescue 0.0); printf("%.8f", x.abs)' -- "$1"; }
num_add() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 0.0); printf("%.8f", a+b)' -- "$1" "$2"; }
num_sub() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 0.0); printf("%.8f", a-b)' -- "$1" "$2"; }
num_mul() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 0.0); printf("%.8f", a*b)' -- "$1" "$2"; }
num_div() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 1.0); printf("%.8f", b==0.0 ? 0.0 : a/b)' -- "$1" "$2"; }
num_gt() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 0.0); exit(a>b ? 0 : 1)' -- "$1" "$2"; }
num_ge() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 0.0); exit(a>=b ? 0 : 1)' -- "$1" "$2"; }
num_lt() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 0.0); exit(a<b ? 0 : 1)' -- "$1" "$2"; }
num_le() { ruby -e 'a=(Float(ARGV[0]) rescue 0.0); b=(Float(ARGV[1]) rescue 0.0); exit(a<=b ? 0 : 1)' -- "$1" "$2"; }

bps_change() {
  local base="$1" px="$2"
  ruby -e 'b=(Float(ARGV[0]) rescue 0.0); p=(Float(ARGV[1]) rescue 0.0); out=(b==0.0 ? 0.0 : ((p-b)/b)*10000.0); printf("%.8f", out)' -- "$base" "$px"
}

public_get() { curl -sS --connect-timeout 10 --max-time 20 "$BASE_URL$1"; }

private_post() {
  local path="$1" q="$2" sig
  sig="$(sign "$q")"
  curl -sS --connect-timeout 10 --max-time 25 -X POST -H "X-MBX-APIKEY: $BINANCE_API_KEY" "$BASE_URL$path?$q&signature=$sig"
}

trend_bps_from_klines() {
  local json="$1"
  ruby -rjson -e '
    arr=JSON.parse(STDIN.read) rescue []
    if !arr.is_a?(Array) || arr.empty?
      print "0"; exit 0
    end
    first=arr.first; last=arr.last
    op=(first[1].to_f rescue 0.0); cl=(last[4].to_f rescue 0.0)
    if op <= 0.0 then print "0" else printf("%.8f", ((cl-op)/op)*10000.0) end
  ' <<< "$json"
}

floor_step_qty() {
  ruby -e '
    q=(Float(ARGV[0]) rescue 0.0); s=(Float(ARGV[1]) rescue 0.001)
    s=0.001 if s <= 0.0
    out=((q/s).floor)*s
    printf("%.8f", out)
  ' -- "$1" "$2"
}

duo_publish_state() {
  local status="$1" side="$2" bps="$3" pnl_usdt="$4" reason="$5" cycle="$6"
  duo_enabled || return 0
  ruby -rjson -e '
    path=ARGV[0]
    data={
      "role"=>ARGV[1],
      "status"=>ARGV[2],
      "side"=>ARGV[3],
      "bps"=>(Float(ARGV[4]) rescue 0.0),
      "pnl_usdt"=>(Float(ARGV[5]) rescue 0.0),
      "reason"=>ARGV[6],
      "cycle"=>ARGV[7],
      "ts_ms"=>(Time.now.to_f*1000).to_i
    }
    begin
      tmp="#{path}.tmp.#{$$}"
      File.write(tmp, JSON.generate(data))
      File.rename(tmp, path)
    rescue
    end
  ' -- "$DUO_STATE_FILE" "$DUO_ROLE" "$status" "$side" "$bps" "$pnl_usdt" "$reason" "$cycle" >/dev/null 2>&1 || true
}

duo_hunter_signal() {
  duo_is_hunter || {
    echo "allow=true mode=disabled forced=AUTO mult=1.0 reason=duo_off"
    return 0
  }
  ruby -rjson -e '
    path=ARGV[0]
    ttl=(Integer(ARGV[1]) rescue 20)
    suffer_bps=(Float(ARGV[2]) rescue -5.0)
    suffer_usdt=(Float(ARGV[3]) rescue -0.5)
    require_sl=(ARGV[4] == "TRUE")
    revenge_mult=ARGV[5]
    force_opp=(ARGV[6] == "TRUE")
    begin
      j=JSON.parse(File.read(path))
    rescue
      puts "allow=false mode=none forced=AUTO mult=1.0 reason=no_state"
      exit 0
    end
    age=((Time.now.to_f*1000).to_i - (j["ts_ms"].to_i rescue 0))
    if age > ttl*1000
      puts "allow=false mode=none forced=AUTO mult=1.0 reason=stale_state"
      exit 0
    end
    side=j["side"].to_s
    forced="AUTO"
    if force_opp
      forced = (side == "BUY" ? "SELL" : (side == "SELL" ? "BUY" : "AUTO"))
    end
    status=j["status"].to_s
    bps=(Float(j["bps"]) rescue 0.0)
    pnl=(Float(j["pnl_usdt"]) rescue 0.0)
    reason=j["reason"].to_s
    suffer = (status == "OPEN") && (bps <= suffer_bps || pnl <= suffer_usdt)
    closed_loss = (status == "CLOSED") && pnl < 0.0
    revenge = closed_loss && (!require_sl || reason == "stop_loss")
    if revenge
      puts "allow=true mode=revenge forced=#{forced} mult=#{revenge_mult} reason=#{reason}"
    elsif suffer
      puts "allow=true mode=suffer forced=#{forced} mult=1.0 reason=#{reason}"
    else
      puts "allow=false mode=none forced=AUTO mult=1.0 reason=no_trigger"
    end
  ' -- "$DUO_STATE_FILE" "$DUO_EVENT_TTL_SEC" "$DUO_SCOUT_SUFFER_BPS" "$DUO_SCOUT_SUFFER_USDT" "$DUO_HUNTER_REQUIRE_STOP_LOSS" "$DUO_HUNTER_REVENGE_MULT" "$DUO_FORCE_OPPOSITE"
}

duo_read_state() {
  duo_enabled || {
    echo "ok=false status=NA side=NA bps=0 pnl=0 reason=na age_ms=999999999"
    return 0
  }
  ruby -rjson -e '
    path=ARGV[0]
    begin
      j=JSON.parse(File.read(path))
    rescue
      puts "ok=false status=NA side=NA bps=0 pnl=0 reason=no_state age_ms=999999999"
      exit 0
    end
    age=((Time.now.to_f*1000).to_i - (j["ts_ms"].to_i rescue 0))
    st=j["status"].to_s
    side=j["side"].to_s
    bps=(Float(j["bps"]) rescue 0.0)
    pnl=(Float(j["pnl_usdt"]) rescue 0.0)
    reason=j["reason"].to_s
    puts "ok=true status=#{st} side=#{side} bps=#{bps} pnl=#{pnl} reason=#{reason} age_ms=#{age}"
  ' -- "$DUO_STATE_FILE"
}

duo_session_update_pnl() {
  local role="$1" pnl_delta="$2"
  duo_enabled || return 0
  ruby -rjson -e '
    path=ARGV[0]
    role=ARGV[1].to_s.downcase
    delta=(Float(ARGV[2]) rescue 0.0)
    begin
      File.open(path, File::RDWR|File::CREAT, 0644) do |f|
        f.flock(File::LOCK_EX)
        raw=f.read
        j=(raw.nil? || raw.empty?) ? {} : (JSON.parse(raw) rescue {})
        j["roles"] ||= {}
        j["roles"][role] = (j["roles"][role].to_f + delta)
        total=0.0
        j["roles"].each_value { |v| total += v.to_f }
        j["total_pnl"] = total
        j["ts_ms"]=(Time.now.to_f*1000).to_i
        f.rewind
        out=JSON.generate(j)
        f.write(out)
        f.truncate(out.bytesize)
      end
    rescue
    end
  ' -- "$DUO_SESSION_FILE" "$role" "$pnl_delta" >/dev/null 2>&1 || true
}

duo_session_total_pnl() {
  duo_enabled || { echo "0"; return 0; }
  ruby -rjson -e '
    path=ARGV[0]
    begin
      j=JSON.parse(File.read(path))
      print(j["total_pnl"] || 0)
    rescue
      print("0")
    end
  ' -- "$DUO_SESSION_FILE"
}

duo_global_stop_hit() {
  duo_enabled || return 1
  if ! num_lt "$DUO_GLOBAL_STOP_SESSION_USDT" "0"; then
    return 1
  fi
  local total
  total="$(duo_session_total_pnl)"
  if num_le "$total" "$DUO_GLOBAL_STOP_SESSION_USDT"; then
    touch "$STOP_FILE" STOP STOP_ALPHA STOP_BETA 2>/dev/null || true
    echo "GLOBAL STOP hit | total_pnl=$total <= $DUO_GLOBAL_STOP_SESSION_USDT"
    return 0
  fi
  return 1
}

symbol_filters() {
  local ex step min
  ex="$(public_get "/fapi/v1/exchangeInfo?symbol=$SYMBOL" || true)"
  step="$(ruby -rjson -e 'j=JSON.parse(STDIN.read) rescue {}; s=(j["symbols"]||[])[0]||{}; f=(s["filters"]||[]).find{|x| x["filterType"]=="LOT_SIZE"}||{}; print(f["stepSize"] || "0.001")' <<< "$ex")"
  min="$(ruby -rjson -e 'j=JSON.parse(STDIN.read) rescue {}; s=(j["symbols"]||[])[0]||{}; f=(s["filters"]||[]).find{|x| x["filterType"]=="LOT_SIZE"}||{}; print(f["minQty"] || "0.001")' <<< "$ex")"
  printf '%s,%s' "$step" "$min"
}

check_radar() {
  local mom_bps="$1" spread_bps="$2"
  radar_direction="long"; radar_reason="radar_off"; radar_conf="0.5"; radar_allow="true"
  if [ "$RADAR_GATE" = "TRUE" ]; then
    radar_out="$(ruby "./radar_gate.rb" \
      --mom-bps "$mom_bps" \
      --spread-bps "$spread_bps" \
      --min-conf "$RADAR_MIN_CONF" \
      --min-mom-bps "$RADAR_MIN_MOM_BPS" \
      --dir-bps "$RADAR_DIR_BPS" \
      --max-spread-bps "$RADAR_MAX_SPREAD_BPS")"
    radar_allow="$(json_get "$radar_out" "allow")"
    radar_direction="$(json_get "$radar_out" "direction")"
    radar_reason="$(json_get "$radar_out" "reason")"
    radar_conf="$(json_get "$radar_out" "confidence")"
  fi
  [ "$radar_allow" = "true" ]
}

apply_dynamic_sizing() {
  local base_usdt="$1"
  local conf="${2:-0}"
  local out="$base_usdt"
  dynamic_size_note="full"
  if [ "$DYNAMIC_SIZING_ENABLED" = "TRUE" ]; then
    if ruby -e 'c=(Float(ARGV[0]) rescue 0.0); lo=(Float(ARGV[1]) rescue 0.15); hi=(Float(ARGV[2]) rescue 0.25); exit((c>=lo && c<=hi) ? 0 : 1)' -- "$conf" "$DYNAMIC_SIZE_CONF_LOW" "$DYNAMIC_SIZE_CONF_HIGH"; then
      out="$(num_mul "$base_usdt" "$DYNAMIC_SIZE_WEAK_FACTOR")"
      dynamic_size_note="weak_conf_half"
    elif ruby -e 'c=(Float(ARGV[0]) rescue 0.0); hi=(Float(ARGV[1]) rescue 0.25); exit(c>hi ? 0 : 1)' -- "$conf" "$DYNAMIC_SIZE_CONF_HIGH"; then
      out="$base_usdt"
      dynamic_size_note="strong_conf_full"
    fi
  fi
  cycle_buy_usdt="$out"
}

detect_soft_anomaly() {
  local tick_bps_abs="$1"
  local anomaly_tick_eff="$ANOMALY_TICK_BPS"
  cycle_buy_usdt="$BUY_USDT"
  cycle_stop_loss_bps="$STOP_LOSS_BPS"
  cycle_trail_giveback_bps="$TRAIL_GIVEBACK_BPS"
  cycle_soft_mode=0

  if num_gt "$LEVERAGE" "1"; then
    anomaly_tick_eff="$(num_mul "$ANOMALY_TICK_BPS" "$LEVERAGE_ANOMALY_MULT")"
  fi

  if [ "$ANOMALY_SOFT_MODE" = "TRUE" ] && [ "$soft_cooldown_remaining" -gt 0 ]; then
    cycle_soft_mode=1
    cycle_buy_usdt="$(num_mul "$cycle_buy_usdt" "$SOFT_MASS_FACTOR")"
    cycle_stop_loss_bps="$SOFT_STOP_LOSS_BPS"
    cycle_trail_giveback_bps="$SOFT_TRAIL_GIVEBACK_BPS"
    soft_cooldown_remaining=$((soft_cooldown_remaining - 1))
  fi
  if [ "$ANOMALY_SOFT_MODE" = "TRUE" ] && num_gt "$tick_bps_abs" "$anomaly_tick_eff"; then
    cycle_soft_mode=1
    cycle_buy_usdt="$(num_mul "$cycle_buy_usdt" "$SOFT_MASS_FACTOR")"
    cycle_stop_loss_bps="$SOFT_STOP_LOSS_BPS"
    cycle_trail_giveback_bps="$SOFT_TRAIL_GIVEBACK_BPS"
    soft_cooldown_remaining="$SOFT_COOLDOWN_CYCLES"
    echo "Cycle $i SOFT anomaly mode ON | tick_bps=$tick_bps_abs > $anomaly_tick_eff"
  fi
}

echo "--- ACE777 STRICT CLONE FUTURES TESTNET ---"
echo "Symbol=$SYMBOL Leverage=$LEVERAGE BuyUSDT=$BUY_USDT Orders=$ENABLE_ORDERS"

ts="$(now_ms)"
q_lev="symbol=$SYMBOL&leverage=$LEVERAGE&timestamp=$ts&recvWindow=$RECV_WINDOW"
lev_resp="$(private_post "/fapi/v1/leverage" "$q_lev" || true)"
lev_code="$(json_get "$lev_resp" "code")"
if [ -n "$lev_code" ]; then
  echo "Abort leverage error: code=$lev_code msg=$(json_get "$lev_resp" "msg")"
  exit 1
fi

IFS=',' read -r lot_step lot_min <<< "$(symbol_filters)"
soft_cooldown_remaining=0
ok_count=0
dynamic_size_note="na"

for i in $(seq 1 "$CYCLES"); do
  dynamic_size_note="na"
  if duo_global_stop_hit; then
    echo "STOP global session detected. Stopping at cycle $i."
    break
  fi
  if [ -f "$STOP_FILE" ]; then
    echo "STOP file detected ($STOP_FILE). Stopping safely at cycle $i."
    break
  fi

  p1_resp="$(public_get "/fapi/v1/ticker/price?symbol=$SYMBOL" || true)"
  p1="$(as_num "$(json_get "$p1_resp" "price")")"
  sleep "$MOMENTUM_SLEEP_SEC"
  p2_resp="$(public_get "/fapi/v1/ticker/price?symbol=$SYMBOL" || true)"
  p2="$(as_num "$(json_get "$p2_resp" "price")")"
  mom_bps="$(bps_change "$p1" "$p2")"
  tick_bps_abs="$(abs_num "$mom_bps")"

  book_resp="$(public_get "/fapi/v1/ticker/bookTicker?symbol=$SYMBOL" || true)"
  bid_px="$(as_num "$(json_get "$book_resp" "bidPrice")")"
  ask_px="$(as_num "$(json_get "$book_resp" "askPrice")")"
  spread_bps="0"
  if num_gt "$ask_px" "0"; then
    spread_bps="$(num_mul "$(num_div "$(num_sub "$ask_px" "$bid_px")" "$ask_px")" "10000")"
  fi

  structure_direction="neutral"
  structure_trend_bps="0"
  if [ "$TREND_FILTER" = "TRUE" ]; then
    limit=$((STRUCTURE_LOOKBACK_MIN + 1))
    tr="$(public_get "/fapi/v1/klines?symbol=$SYMBOL&interval=1m&limit=$limit" || true)"
    structure_trend_bps="$(trend_bps_from_klines "$tr")"
    if num_ge "$structure_trend_bps" "1"; then
      structure_direction="long"
    elif num_le "$structure_trend_bps" "-1"; then
      structure_direction="short"
    fi
  fi

  mom_direction="neutral"
  if num_ge "$mom_bps" "$MOMENTUM_THRESHOLD"; then
    mom_direction="long"
  elif num_le "$mom_bps" "-$MOMENTUM_THRESHOLD"; then
    mom_direction="short"
  fi

  if ! check_radar "$mom_bps" "$spread_bps"; then
    echo "$(date -u +%FT%TZ),$i,SKIP,SKIPPED,,,,,0,radar_block,reason=$radar_reason conf=$radar_conf mom_bps=$mom_bps spread_bps=$spread_bps" >> "$LOG_FILE"
    echo "Cycle $i SKIP | radar blocked: reason=$radar_reason conf=$radar_conf"
    sleep "$SLEEP_SEC"
    continue
  fi

  if [ "$TREND_FILTER" = "TRUE" ] && [ "$structure_direction" != "neutral" ]; then
    radar_direction="$structure_direction"
  fi
  if [ "$ENTRY_SIGNAL" = "CROSSOVER" ] && [ "$TREND_FILTER" = "TRUE" ] && [ "$structure_direction" != "neutral" ]; then
    if [ "$mom_direction" != "neutral" ] && [ "$mom_direction" != "$structure_direction" ]; then
      echo "$(date -u +%FT%TZ),$i,SKIP,SKIPPED,,,,,0,tactic_mismatch,mom=$mom_direction structure=$structure_direction" >> "$LOG_FILE"
      echo "Cycle $i SKIP | tactic mismatch mom=$mom_direction structure=$structure_direction"
      sleep "$SLEEP_SEC"
      continue
    fi
  fi

  detect_soft_anomaly "$tick_bps_abs"
  apply_dynamic_sizing "$cycle_buy_usdt" "$radar_conf"

  if [ "$ENABLE_ORDERS" != "TRUE" ]; then
    echo "$(date -u +%FT%TZ),$i,OBSERVE,NA,$p1,$p2,0,$mom_bps,0,observe_only,ok" >> "$LOG_FILE"
    echo "Cycle $i/$CYCLES OBSERVE | mom_bps=$mom_bps radar=$radar_direction"
    sleep "$SLEEP_SEC"
    continue
  fi

  side="BUY"; close_side="SELL"; signed_dir="1"
  if [ "$radar_direction" = "short" ] && num_le "$mom_bps" "-$MOMENTUM_THRESHOLD"; then
    side="SELL"; close_side="BUY"; signed_dir="-1"
  fi
  if [ "$FORCE_ENTRY_SIDE" = "BUY" ]; then
    side="BUY"; close_side="SELL"; signed_dir="1"
  elif [ "$FORCE_ENTRY_SIDE" = "SELL" ]; then
    side="SELL"; close_side="BUY"; signed_dir="-1"
  fi

  duo_mode_note="na"
  if duo_is_hunter; then
    duo_sig="$(duo_hunter_signal)"
    duo_allow="false"; duo_forced="AUTO"; duo_mult="1.0"; duo_mode_note="none"; duo_reason="na"
    for tok in $duo_sig; do
      case "$tok" in
        allow=*) duo_allow="${tok#allow=}" ;;
        forced=*) duo_forced="${tok#forced=}" ;;
        mult=*) duo_mult="${tok#mult=}" ;;
        mode=*) duo_mode_note="${tok#mode=}" ;;
        reason=*) duo_reason="${tok#reason=}" ;;
      esac
    done
    if [ "$duo_allow" != "true" ]; then
      echo "$(date -u +%FT%TZ),$i,SKIP,SKIPPED,,,,,0,duo_wait,reason=$duo_reason mode=$duo_mode_note" >> "$LOG_FILE"
      echo "Cycle $i SKIP | duo hunter waiting: reason=$duo_reason"
      sleep "$SLEEP_SEC"
      continue
    fi
    if [ "$duo_forced" = "BUY" ]; then
      side="BUY"; close_side="SELL"; signed_dir="1"
    elif [ "$duo_forced" = "SELL" ]; then
      side="SELL"; close_side="BUY"; signed_dir="-1"
    fi
    if [ "$duo_mode_note" = "revenge" ]; then
      cycle_buy_usdt="$(num_mul "$cycle_buy_usdt" "$duo_mult")"
      dynamic_size_note="hunter_revenge_${duo_mult}x"
    fi
  fi

  position_side_param=""
  if [ "$POSITION_SIDE" = "LONG" ] || [ "$POSITION_SIDE" = "SHORT" ]; then
    position_side_param="&positionSide=$POSITION_SIDE"
  fi

  raw_qty="$(num_div "$(num_mul "$cycle_buy_usdt" "$LEVERAGE")" "$p2")"
  qty="$(floor_step_qty "$raw_qty" "$lot_step")"
  if ! num_ge "$qty" "$lot_min"; then
    echo "$(date -u +%FT%TZ),$i,SKIP,$side,$p2,,$qty,0,0,qty_too_small,min=$lot_min" >> "$LOG_FILE"
    echo "Cycle $i SKIP | qty too small ($qty < $lot_min)"
    sleep "$SLEEP_SEC"
    continue
  fi

  ts="$(now_ms)"
  q_entry="symbol=$SYMBOL&side=$side&type=MARKET&quantity=$qty${position_side_param}&timestamp=$ts&recvWindow=$RECV_WINDOW"
  entry_resp="$(private_post "/fapi/v1/order" "$q_entry" || true)"
  entry_code="$(json_get "$entry_resp" "code")"
  if [ -n "$entry_code" ]; then
    msg="$(json_get "$entry_resp" "msg")"
    echo "$(date -u +%FT%TZ),$i,ENTRY_ERROR,$side,$p2,,$qty,0,0,entry_error,code=$entry_code msg=$msg" >> "$LOG_FILE"
    echo "Cycle $i ENTRY error: code=$entry_code msg=$msg"
    sleep "$SLEEP_SEC"
    continue
  fi

  entry_price="$(as_num "$(json_get "$entry_resp" "avgPrice")")"
  if ! num_gt "$entry_price" "0"; then entry_price="$p2"; fi

  reason="timeout"
  start_s="$(now_sec)"
  peak_bps="-999999.00000000"
  prev_bps=""
  prev_ts="$(now_sec)"
  fatigue_count=0
  slow_velocity_count=0
  current_bps="0"
  current_pnl_live="0"
  while true; do
    if [ -f "$STOP_FILE" ]; then reason="kill_switch"; break; fi
    now_s="$(now_sec)"
    hold_sec=$((now_s - start_s))

    tick_resp="$(public_get "/fapi/v1/ticker/price?symbol=$SYMBOL" || true)"
    px="$(as_num "$(json_get "$tick_resp" "price")")"
    current_bps="$(num_mul "$(bps_change "$entry_price" "$px")" "$signed_dir")"
    current_pnl_live="$(num_mul "$(num_sub "$px" "$entry_price")" "$(num_mul "$qty" "$signed_dir")")"
    if num_ge "$current_bps" "$peak_bps"; then peak_bps="$current_bps"; fi
    if duo_is_scout; then
      duo_publish_state "OPEN" "$side" "$current_bps" "$current_pnl_live" "running" "$i"
    fi

    scout_status="NA"; scout_pnl="0"; scout_age_ms="999999999"; scout_reason="na"
    hunter_block_exit=0
    if duo_is_hunter; then
      ds="$(duo_read_state)"
      ds_ok="false"
      for tok in $ds; do
        case "$tok" in
          ok=*) ds_ok="${tok#ok=}" ;;
          status=*) scout_status="${tok#status=}" ;;
          pnl=*) scout_pnl="${tok#pnl=}" ;;
          age_ms=*) scout_age_ms="${tok#age_ms=}" ;;
          reason=*) scout_reason="${tok#reason=}" ;;
        esac
      done
      if [ "$DUO_HUNTER_PERSIST_LINK" = "TRUE" ] && [ "$ds_ok" = "true" ] && [ "$scout_status" = "OPEN" ]; then
        basket_pnl_live="$(num_add "$current_pnl_live" "$scout_pnl")"
        if num_lt "$basket_pnl_live" "0"; then
          hunter_block_exit=1
        fi
      fi
    fi

    active_trail_arm_bps="$TRAIL_ARM_BPS"

    if [ "$CALORIE_EFFICIENCY_EXIT" = "TRUE" ] && [ "$hold_sec" -ge "$MIN_HOLD_SEC" ]; then
      now_tick="$(now_sec)"
      dt=$((now_tick - prev_ts)); [ "$dt" -le 0 ] && dt=1
      if [ -n "$prev_bps" ]; then
        delta_bps="$(num_sub "$current_bps" "$prev_bps")"
        vel_bps_s="$(num_div "$(abs_num "$delta_bps")" "$dt")"
        if num_lt "$vel_bps_s" "$STALL_THRESHOLD_BPS_PER_SEC"; then
          slow_velocity_count=$((slow_velocity_count + 1))
        else
          slow_velocity_count=0
        fi
        if [ "$slow_velocity_count" -ge "$FATIGUE_CONFIRMATIONS" ]; then
          fatigue_count=$((fatigue_count + 1))
          if [ "$fatigue_count" -ge "$FATIGUE_CONFIRMATIONS" ]; then
            reason="exit_fatigue"; break
          fi
        fi
      fi
      prev_bps="$current_bps"
      prev_ts="$now_tick"
    fi

    active_stop_loss_bps="$cycle_stop_loss_bps"
    active_trail_giveback_bps="$cycle_trail_giveback_bps"
    if duo_is_hunter && num_gt "$DUO_HUNTER_STOP_LOSS_BPS" "0"; then
      active_stop_loss_bps="$DUO_HUNTER_STOP_LOSS_BPS"
    fi
    # Anti-panique: no anomaly-driven cut in the first few seconds.
    if [ "$cycle_soft_mode" -eq 1 ] && [ "$hold_sec" -lt "$MIN_HOLD_FOR_ANOMALY" ]; then
      active_stop_loss_bps="$STOP_LOSS_BPS"
      active_trail_giveback_bps="$TRAIL_GIVEBACK_BPS"
    fi
    # Neutral zone protection: do not let soft-anomaly cut too early.
    if [ "$cycle_soft_mode" -eq 1 ] && [ "$hold_sec" -lt "$SOFT_NEUTRAL_HOLD_SEC" ]; then
      if num_ge "$current_bps" "$NEUTRAL_PNL_MIN_BPS" && num_le "$current_bps" "$NEUTRAL_PNL_MAX_BPS"; then
        active_stop_loss_bps="$STOP_LOSS_BPS"
        active_trail_giveback_bps="$TRAIL_GIVEBACK_BPS"
      fi
    fi

    if duo_is_hunter && [ "$DUO_MOMENTUM_HANDOVER" = "TRUE" ] && [ "$scout_status" = "CLOSED" ]; then
      if ruby -e 'age=(Integer(ARGV[0]) rescue 999999999); ttl=(Integer(ARGV[1]) rescue 20); exit(age <= ttl*1000 ? 0 : 1)' -- "$scout_age_ms" "$DUO_EVENT_TTL_SEC"; then
        active_trail_arm_bps="$DUO_HUNTER_AGGR_TRAIL_ARM_BPS"
        active_trail_giveback_bps="$DUO_HUNTER_AGGR_TRAIL_GIVEBACK_BPS"
      fi
    fi

    if [ "$hold_sec" -ge "$MAX_HOLD_SEC" ]; then
      if duo_is_hunter && [ "$hunter_block_exit" -eq 1 ] && [ "$hold_sec" -lt "$DUO_HUNTER_MAX_HOLD_SEC" ]; then
        :
      else
        reason="timeout"; break
      fi
    fi

    if num_le "$current_bps" "-$active_stop_loss_bps"; then
      if duo_is_hunter && [ "$hunter_block_exit" -eq 1 ]; then
        hard_stop_bps="$(num_mul "$active_stop_loss_bps" "$DUO_HUNTER_HARD_STOP_MULT")"
        if num_le "$current_bps" "-$hard_stop_bps"; then
          reason="stop_loss"; break
        fi
      else
        reason="stop_loss"; break
      fi
    fi

    if [ "$USE_TRAILING" = "1" ]; then
      if num_ge "$peak_bps" "$active_trail_arm_bps"; then
        trail_floor="$(num_sub "$peak_bps" "$active_trail_giveback_bps")"
        if num_le "$current_bps" "$trail_floor"; then
          if duo_is_hunter && [ "$hunter_block_exit" -eq 1 ]; then
            :
          else
            reason="trailing_stop"; break
          fi
        fi
      fi
    else
      if num_ge "$current_bps" "$MIN_PROFIT_BPS"; then
        if duo_is_hunter && [ "$hunter_block_exit" -eq 1 ]; then
          :
        else
          reason="target"; break
        fi
      fi
    fi
    sleep "$POLL_SEC"
  done

  ts="$(now_ms)"
  if [ "$POSITION_SIDE" = "BOTH" ]; then
    q_exit="symbol=$SYMBOL&side=$close_side&type=MARKET&quantity=$qty&reduceOnly=true&timestamp=$ts&recvWindow=$RECV_WINDOW"
  else
    q_exit="symbol=$SYMBOL&side=$close_side&type=MARKET&quantity=$qty${position_side_param}&timestamp=$ts&recvWindow=$RECV_WINDOW"
  fi
  exit_resp="$(private_post "/fapi/v1/order" "$q_exit" || true)"
  exit_code="$(json_get "$exit_resp" "code")"
  if [ -n "$exit_code" ]; then
    msg="$(json_get "$exit_resp" "msg")"
    echo "$(date -u +%FT%TZ),$i,EXIT_ERROR,$side,$entry_price,,$qty,$current_bps,0,$reason,code=$exit_code msg=$msg" >> "$LOG_FILE"
    echo "Cycle $i EXIT error: code=$exit_code msg=$msg"
    sleep "$SLEEP_SEC"
    continue
  fi

  exit_price="$(as_num "$(json_get "$exit_resp" "avgPrice")")"
  if ! num_gt "$exit_price" "0"; then
    if [ -n "${px:-}" ] && num_gt "${px:-0}" "0"; then
      exit_price="$px"
    else
      exit_price="$p2"
    fi
  fi
  bps="$(num_mul "$(bps_change "$entry_price" "$exit_price")" "$signed_dir")"
  pct="$(num_div "$bps" "100")"
  pnl_usdt="$(num_mul "$(num_sub "$exit_price" "$entry_price")" "$(num_mul "$qty" "$signed_dir")")"
  if duo_enabled; then
    duo_session_update_pnl "$DUO_ROLE" "$pnl_usdt"
  fi
  if duo_is_scout; then
    duo_publish_state "CLOSED" "$side" "$bps" "$pnl_usdt" "$reason" "$i"
  fi
  anomaly_pnl_eff="$ANOMALY_PNL_USDT"
  if num_gt "$LEVERAGE" "1"; then
    anomaly_pnl_eff="$(num_mul "$ANOMALY_PNL_USDT" "$LEVERAGE_ANOMALY_MULT")"
  fi
  if [ "$ANOMALY_SOFT_MODE" = "TRUE" ] && num_gt "$(abs_num "$pnl_usdt")" "$anomaly_pnl_eff"; then
    soft_cooldown_remaining="$SOFT_COOLDOWN_CYCLES"
    echo "Cycle $i SOFT anomaly mode ON | pnl_abs=$(abs_num "$pnl_usdt") > $anomaly_pnl_eff"
  fi
  hold_done=$(( $(now_sec) - start_s ))
  echo "$(date -u +%FT%TZ),$i,$side,FILLED,$entry_price,$exit_price,$qty,$bps,$pnl_usdt,$reason,radar=$radar_direction conf=$radar_conf size_note=$dynamic_size_note soft=$cycle_soft_mode pct=$pct" >> "$LOG_FILE"
  echo "Cycle $i/$CYCLES ORDER | side=$side qty=$qty reason=$reason hold=${hold_done}s bps=$bps pct=${pct}% pnl=$pnl_usdt conf=$radar_conf size=$dynamic_size_note"
  if duo_global_stop_hit; then
    echo "STOP global session detected after cycle $i."
    break
  fi
  ok_count=$((ok_count + 1))
  sleep "$SLEEP_SEC"
done

echo
echo "Done."
echo "Log: $LOG_FILE"
echo "Successful order-cycles: $ok_count"
